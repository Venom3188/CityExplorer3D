# City Explorer 3D — Ultimate Android Project V3

An Android Studio project wrapping an offline-friendly city exploration game in an immersive Android WebView.

## Expansion pack (V3)
- **Career mode:** contracts, driver ranks, XP and career funds.
- **City time trial:** six checkpoints, a timer, and a completion reward.
- **Property ownership:** buy a starter home with coins, visit it, and purchase furniture sets.
- **Multiplayer hub prototype:** create/share a sample lobby code and enter a code. This is only the lobby/interface prototype; live online players require a hosted real-time game server and networking implementation.
- **Five city themes:** Lagos Metro, Abuja Capital, Accra Coast, Dubai Skyline and Tokyo District.
- **Exploration:** enterable building/shop interiors, character outfit colors, parked cars, moving traffic, pedestrians, coins, missions, wanted level and police pursuit.
- **Driving:** arcade vehicle handling and purchasable upgrades.
- **Mobile features:** touchscreen controls, minimap, camera toggle, day/evening cycle, pause/restart and local save data.

## Build an APK
1. Install Android Studio on a computer.
2. Open the `CityExplorerAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location; commonly `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that file source in Android settings.

## Important limitations
- This ZIP is project source, **not a precompiled APK**. Build and test it in Android Studio before installing or sharing.
- The current renderer is a lightweight pseudo-3D canvas renderer, not a realistic full 3D engine. A full 3D conversion would require a 3D engine/assets and additional implementation.
- Online multiplayer is not live until a server, networking, and player synchronization are added.

## Build the APK online with GitHub Actions (no Android Studio needed on your phone)
This project includes `.github/workflows/android-apk.yml` for a cloud build. You still need access to a GitHub account and a browser:
1. Create a new GitHub repository.
2. Upload the **contents** of this `CityExplorerAndroid` folder to the repository (make sure `.github/workflows/android-apk.yml` is included).
3. Open the repository's **Actions** tab and select **Build City Explorer 3D APK**.
4. If prompted, enable workflows, then choose **Run workflow**.
5. When the workflow finishes successfully, open the completed run and download the `CityExplorer3D-debug-APK` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

This cloud workflow has been added but has **not been run or verified in this environment**. If the build fails, the workflow's build log will show the error to fix. The resulting debug APK is for testing, not a signed release for publishing.
